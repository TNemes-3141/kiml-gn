"""Aufgabe 4: Entscheidungsbäume

Bibliotheken importieren (nicht bearbeiten):
"""

import pandas as pd
from sklearn.tree import DecisionTreeClassifier

import warnings
warnings.filterwarnings('ignore')

"""Datensatz laden und vorbereiten (nicht bearbeiten):"""

train_df = pd.read_csv("student_train.csv")
test_df = pd.read_csv("student_test.csv")

print("Trainingsdatensatz (Ausschnitt):")
print(train_df.head())
print("\nTestdatensatz (Ausschnitt):")
print(test_df.head())

# Features und Labels trennen
X_train = train_df.drop(columns=['Cover_Type'])
y_train = train_df['Cover_Type'].values
X_test = test_df.copy()

print("\nDaten erfolgreich geladen und vorbereitet!")

"""Konfigurieren Sie hier Ihren Entscheidungsbaum (HIER BEARBEITEN)!
"""

# === ZU BEARBEITENDER BLOCK ===
# Stellen Sie die fünf Hyperparameter ein

MAX_DEPTH = # ...
CRITERION = # ...
MIN_SAMPLES_LEAF = # ...
MIN_SAMPLES_SPLIT = # ...
MAX_FEATURES = # ...

# --- MODELL ERSTELLEN (nicht bearbeiten) ---
covertype_tree = DecisionTreeClassifier(
    max_depth=MAX_DEPTH,
    criterion=CRITERION,
    min_samples_leaf=MIN_SAMPLES_LEAF,
    min_samples_split=MIN_SAMPLES_SPLIT,
    max_features=MAX_FEATURES,
    random_state=0,
)

"""Nun lassen wir das Modell anhand der Trainingsdaten lernen. Sobald das Training abgeschlossen ist, wird das Modell die Baumarten für den Testsatz vorhersagen und zur Bewertung in einer CSV mit dem Namen `result.csv` speichern."""

covertype_tree.fit(X_train, y_train)

print("\nTraining abgeschlossen! Vorhersagen für den Testsatz werden generiert...")
predictions = covertype_tree.predict(X_test)

# Vorhersagen speichern
submission_df = pd.DataFrame({'Cover_Type': predictions})
submission_filename = 'result.csv'
submission_df.to_csv(submission_filename, index=False)

print(f"\nVorhersage abgeschlossen! Die Datei wurde als '{submission_filename}' heruntergeladen.")
print("Laden Sie diese Datei nun auf den Bewertungsserver hoch.")