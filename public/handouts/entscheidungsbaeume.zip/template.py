# This is a template file for the task "entscheidungsbaeume"

if __name__ == "__main__":
    print("Hello, decision trees!")