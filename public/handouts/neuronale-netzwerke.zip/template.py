# This is a template file for the task "neuronale-netzwerke"

if __name__ == "__main__":
    print("Hello, neural networks!")