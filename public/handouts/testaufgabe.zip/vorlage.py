import pandas as pd
import numpy as np

def load_test_features(filepath: str) -> np.ndarray:
    """
    Lädt die Testdaten (Features) aus der angegebenen CSV-Datei.
    """
    df = pd.read_csv(filepath)
    return df.values

def predict(X: np.ndarray, parameters: list) -> np.ndarray:
    """
    Erzeugt Vorhersagen durch ein einfaches Skalarprodukt (Dot-Product) 
    aus den Features und den übergebenen Parametern.
    """
    weights = np.array(parameters)
    return np.dot(X, weights)

def save_predictions(predictions: np.ndarray, filepath: str):
    """
    Speichert die Vorhersagen im korrekten Format als result.csv.
    """
    df = pd.DataFrame(predictions, columns=["prediction"])
    df.to_csv(filepath, index=False)
    print(f"Erfolg! Vorhersagen wurden in '{filepath}' gespeichert.")

def main():
    # --- ZU BEARBEITENDER BEREICH ---
    
    # Um die Baseline zu übertreffen, musst du die schlechten Parameter
    # durch die guten Parameter ersetzen. Kopiere diese Liste:
    # GUTE PARAMETER: [0.0315, 0.1048, 0.6371, 0.1681, 0.7061]
    
    parameters = [0.0, 0.0, 0.0, 0.0, 0.0]
    
    # --------------------------------
    
    print("Lade Testdaten...")
    X_test = load_test_features("test.csv")
    
    print("Erstelle Vorhersagen...")
    predictions = predict(X_test, parameters)
    
    print("Speichere Ergebnisse...")
    save_predictions(predictions, "result.csv")

if __name__ == "__main__":
    main()